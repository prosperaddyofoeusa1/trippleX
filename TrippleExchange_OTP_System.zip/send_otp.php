<?php
header('Content-Type: application/json');
require 'config.php';

$data = json_decode(file_get_contents('php://input'), true);
$email = $data['email'] ?? '';
$method = $data['method'] ?? 'email';

if (!$email || $method !== 'email') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid input']);
    exit;
}

$otp = rand(100000, 999999);
$expires = date('Y-m-d H:i:s', time() + 600); // 10 minutes

$stmt = $conn->prepare("INSERT INTO otp_verification (email, otp, expires_at) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE otp=?, expires_at=?");
$stmt->bind_param("sssss", $email, $otp, $expires, $otp, $expires);
$stmt->execute();

if (sendEmailOTP($email, $otp)) {
    echo json_encode(['status' => 'success', 'otp' => $otp]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Failed to send OTP']);
}
?>
