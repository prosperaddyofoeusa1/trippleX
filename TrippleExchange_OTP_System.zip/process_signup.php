<?php
header('Content-Type: application/json');
require 'config.php';

$username = $_POST['username'] ?? '';
$email = $_POST['email'] ?? '';
$password = password_hash($_POST['password'], PASSWORD_BCRYPT);
$phone = $_POST['phone'] ?? '';
$timezone = $_POST['timezone'] ?? '';
$ip = $_POST['user_ip'] ?? '';
$location = $_POST['location'] ?? '';

$stmt = $conn->prepare("INSERT INTO users (username, email, password, phone, timezone, ip_address, location) VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sssssss", $username, $email, $password, $phone, $timezone, $ip, $location);

if ($stmt->execute()) {
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Signup failed: ' . $conn->error]);
}
?>
