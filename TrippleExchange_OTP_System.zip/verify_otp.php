<?php
header('Content-Type: application/json');
require 'config.php';

$email = $_POST['email'] ?? '';
$otp = $_POST['otp'] ?? '';

$stmt = $conn->prepare("SELECT * FROM otp_verification WHERE email=? AND otp=? AND expires_at > NOW()");
$stmt->bind_param("ss", $email, $otp);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid or expired OTP']);
}
?>
