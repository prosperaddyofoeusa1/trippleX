<?php
$db_host = 'localhost';
$db_user = 'u925878138_admin';
$db_pass = 'Chills@1008!!';
$db_name = 'u925878138_tripplex';

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';
require 'PHPMailer/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;

function sendEmailOTP($toEmail, $otp) {
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.hostinger.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'support@trippleexchange.com';
        $mail->Password = 'oFuUb3PDLw9nT8R2DEBEfg';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom('support@trippleexchange.com', 'Triple Exchange');
        $mail->addAddress($toEmail);
        $mail->Subject = 'Your Verification Code';
        $mail->Body = "Your OTP is: $otp\n\nIt will expire in 10 minutes.";

        $mail->send();
        return true;
    } catch (Exception $e) {
        return false;
    }
}
?>
