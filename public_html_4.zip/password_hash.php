<?php
echo password_hash('Chills@1008...', PASSWORD_BCRYPT);
?>
