<?php
require '../../config.php'; // path as appropriate
$rows = [];
$res = $mysqli->query("SELECT * FROM deposit_addresses ORDER BY coin, network");
while($row = $res->fetch_assoc()) $rows[] = $row;
echo json_encode(['success'=>true, 'addresses'=>$rows]);
?>
