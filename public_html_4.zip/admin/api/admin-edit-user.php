<?php
session_start();
if (empty($_SESSION['admin_logged_in'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Admin not authenticated']);
    exit;
}
require_once '../config.php';
header('Content-Type: application/json');
$data = json_decode(file_get_contents('php://input'), true);
$id = (int)($data['id'] ?? 0);
$name = trim($data['name'] ?? '');
$email = trim($data['email'] ?? '');
$status = trim($data['status'] ?? '');
$kyc_status = trim($data['kyc_status'] ?? '');

if (!$id || !$name || !$email) {
    echo json_encode(['success' => false, 'message' => 'Missing fields']);
    exit;
}
try {
    $stmt = $pdo->prepare("UPDATE users SET name=?, email=?, status=?, kyc_status=? WHERE id=?");
    $stmt->execute([$name, $email, $status, $kyc_status, $id]);
    echo json_encode(['success' => true]);
} catch(Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
