<?php
header('Content-Type: application/json');
require_once '../../config.php'; // <-- Adjust path if needed

// Only accept JSON POST
$data = json_decode(file_get_contents("php://input"), true);

$section = isset($data['section']) ? trim($data['section']) : '';
$content = isset($data['content']) ? trim($data['content']) : '';

if (!$section || $content === '') {
    echo json_encode(['success' => false, 'message' => 'Missing section or content']);
    exit;
}

// Save or update
$stmt = $mysqli->prepare("INSERT INTO site_content (section, content) VALUES (?, ?)
    ON DUPLICATE KEY UPDATE content = VALUES(content), updated_at = CURRENT_TIMESTAMP");
$stmt->bind_param('ss', $section, $content);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => $mysqli->error]);
}
$stmt->close();
?>
