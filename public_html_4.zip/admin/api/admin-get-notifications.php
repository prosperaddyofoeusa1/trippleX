<?php
header('Content-Type: application/json');
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/config.php';

try {
    $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
    $limit = 10;
    $offset = ($page - 1) * $limit;
    $where = '1=1';
    $params = [];

    if (!empty($_GET['recipient'])) {
        $where .= " AND recipient = :recipient";
        $params[':recipient'] = $_GET['recipient'];
    }
    if (!empty($_GET['date'])) {
        $where .= " AND DATE(created_at) = :date";
        $params[':date'] = $_GET['date'];
    }

    $stmt = $pdo->prepare("SELECT SQL_CALC_FOUND_ROWS * FROM notifications WHERE $where ORDER BY created_at DESC LIMIT $limit OFFSET $offset");
    $stmt->execute($params);
    $notifications = $stmt->fetchAll();

    $totalRows = $pdo->query("SELECT FOUND_ROWS()")->fetchColumn();
    $totalPages = ceil($totalRows / $limit);

    echo json_encode([
        'success' => true,
        'notifications' => $notifications,
        'page' => $page,
        'totalPages' => $totalPages,
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Server error: ' . $e->getMessage()
    ]);
}
