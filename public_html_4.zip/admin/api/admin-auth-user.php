<?php
$_SESSION['admin_logged_in'] = true;
$_SESSION['admin_id'] = $admin_id; // Or any unique admin value
require '../config.php';
$data = json_decode(file_get_contents('php://input'), true);
$id = (int)($data['id']??0);
$kyc_status = $data['kyc_status']??'pending';
if(!$id || !in_array($kyc_status,['pending','approved','rejected'])) die(json_encode(['success'=>false,'message'=>'Invalid input']));
$stmt = $pdo->prepare("UPDATE users SET kyc_status=? WHERE id=?");
$res = $stmt->execute([$kyc_status, $id]);
echo json_encode(['success'=>$res]);
