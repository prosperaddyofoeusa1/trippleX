<?php
header('Content-Type: application/json');
require_once '../../config.php'; // <-- Adjust path if needed

$section = isset($_GET['section']) ? trim($_GET['section']) : '';
if (!$section) {
    echo json_encode(['success' => false, 'content' => '', 'message' => 'No section specified']);
    exit;
}

$stmt = $mysqli->prepare("SELECT content FROM site_content WHERE section = ?");
$stmt->bind_param('s', $section);
$stmt->execute();
$stmt->bind_result($content);
$stmt->fetch();
$stmt->close();

echo json_encode([
    'success' => true,
    'content' => $content ?: ''
]);
?>
