<?php
header('Content-Type: application/json');
require_once '../config.php'; // Update the path as needed

$data = json_decode(file_get_contents('php://input'), true);
if (!$data) {
    echo json_encode(['success' => false, 'message' => 'No input received']);
    exit;
}

$keys = ['site_name', 'support_email', 'withdrawal_fee', 'min_withdrawal', 'maintenance'];
$success = true;

foreach ($keys as $key) {
    if (!isset($data[$key])) {
        echo json_encode(['success' => false, 'message' => "Missing setting: $key"]);
        exit;
    }
}

try {
    $stmt = $mysqli->prepare("UPDATE site_settings SET setting_value = ? WHERE setting_key = ?");
    foreach ($keys as $key) {
        $stmt->bind_param('ss', $data[$key], $key);
        $stmt->execute();
    }
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
