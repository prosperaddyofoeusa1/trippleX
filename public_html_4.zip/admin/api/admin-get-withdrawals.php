<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');

// Database connection
require_once 'config.php';

// Optional: Search filter
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

try {
    // Build WHERE clause if searching
    $where = "";
    $params = [];

    if ($search) {
        $where = "WHERE (u.email LIKE :search OR u.id LIKE :searchid)";
        $params[':search'] = '%' . $search . '%';
        $params[':searchid'] = '%' . $search . '%';
    }

    // Main query with JOIN to users table
    $sql = "SELECT w.id, w.amount, w.coin, w.network, w.to_address, w.status, w.created_at, u.email
            FROM withdrawals w
            LEFT JOIN users u ON w.user_id = u.id
            $where
            ORDER BY w.id DESC";

    $stmt = $pdo->prepare($sql);
    foreach ($params as $key => $val) {
        $stmt->bindValue($key, $val, PDO::PARAM_STR);
    }
    $stmt->execute();
    $withdrawals = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['success' => true, 'withdrawals' => $withdrawals]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    exit;
}
?>
