<?php
require_once __DIR__ . '/../db-connect.php';
header('Content-Type: application/json');

$token = $_GET['token'] ?? '';
if (!$token) {
  echo json_encode(['success' => false, 'message' => 'No token provided']);
  exit;
}

$stmt = $pdo->prepare("SELECT u.* FROM user_tokens t JOIN users u ON t.user_id = u.id WHERE t.token = ? AND t.expires_at > NOW()");
$stmt->execute([$token]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user) {
  echo json_encode([
    'success' => true,
    'user' => [
      'id' => $user['id'],
      'username' => $user['username'],
      'email' => $user['email'],
      'wallet_balance' => $user['wallet_balance'],
      'kyc_status' => $user['kyc_status']
    ]
  ]);
} else {
  echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
}
