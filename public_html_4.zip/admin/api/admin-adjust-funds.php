<?php
require 'config.php';
header('Content-Type: application/json');
$data = json_decode(file_get_contents("php://input"), true);
$user_id = intval($data['user_id'] ?? 0);
$action = $data['action'] ?? '';
$amount = floatval($data['amount'] ?? 0);
$currency = $data['currency'] ?? 'USD'; // Can use only for multi-currency
$notes = trim($data['notes'] ?? '');

if (!$user_id || !$action || $amount <= 0) die(json_encode(['success'=>false,'message'=>'Invalid']));

// Example for USD only:
if ($action === 'deposit') {
  $pdo->prepare("UPDATE users SET wallet_balance = wallet_balance + ? WHERE id=?")->execute([$amount, $user_id]);
} elseif ($action === 'withdraw') {
  $pdo->prepare("UPDATE users SET wallet_balance = wallet_balance - ? WHERE id=?")->execute([$amount, $user_id]);
} elseif ($action === 'adjust') {
  $pdo->prepare("UPDATE users SET wallet_balance = ? WHERE id=?")->execute([$amount, $user_id]);
}
// Optional: Log this adjustment in a `funds_logs` table with reason.
echo json_encode(['success'=>true]);
?>
