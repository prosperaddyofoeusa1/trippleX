<?php
require 'config.php';
header('Content-Type: application/json');
$data = json_decode(file_get_contents("php://input"), true);
$id = intval($data['id'] ?? 0);
if (!$id) die(json_encode(['success'=>false]));
$ok = $pdo->prepare("DELETE FROM users WHERE id=?")->execute([$id]);
echo json_encode(['success'=>$ok]);
?>
