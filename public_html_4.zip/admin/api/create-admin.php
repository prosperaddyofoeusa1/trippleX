<?php
// admin/api/create-admin.php

// Change these to the admin credentials you want to create
$newUsername = 'jax';
$newPassword = 'admin@123'; // Choose a strong password

// Your DB credentials
$DB_HOST = 'localhost';
$DB_USER = 'u925878138_admin';
$DB_PASS = 'Chills@1008!!';
$DB_NAME = 'u925878138_tripplex';

try {
    $pdo = new PDO("mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4", $DB_USER, $DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Hash the password securely
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

    // Insert user
    $stmt = $pdo->prepare("INSERT INTO admins (username, password_hash) VALUES (:username, :password)");
    $stmt->execute([
        ':username' => $newUsername,
        ':password' => $hashedPassword
    ]);

    echo json_encode(['success' => true, 'message' => 'Admin user created successfully!']);
} catch (PDOException $e) {
    if ($e->getCode() == 23000) {
        echo json_encode(['success' => false, 'message' => 'Username already exists.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
}
