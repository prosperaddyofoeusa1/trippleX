<?php
session_start();
require '../../config.php'; // adjust if config is not one level up!
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    http_response_code(401); exit;
}
$data = json_decode(file_get_contents('php://input'), true);
$id = isset($data['id']) ? intval($data['id']) : 0;
$coin = $data['coin'];
$network = $data['network'];
$address = $data['address'];
$label = $data['label'];
if($id) {
    $stmt = $mysqli->prepare("UPDATE deposit_addresses SET coin=?, network=?, address=?, label=? WHERE id=?");
    $stmt->bind_param("ssssi", $coin, $network, $address, $label, $id);
} else {
    $stmt = $mysqli->prepare("INSERT INTO deposit_addresses (coin, network, address, label) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $coin, $network, $address, $label);
}
if($stmt->execute()) {
    echo json_encode(['success'=>true]);
} else {
    echo json_encode(['success'=>false, 'message'=>'DB error: ' . $stmt->error]);
}
?>
