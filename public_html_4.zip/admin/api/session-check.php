<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
  echo json_encode(['loggedIn' => false]);
  exit;
}

require_once '../db-connect.php';
$stmt = $pdo->prepare("SELECT username, wallet_balance, kyc_status FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
  echo json_encode(['loggedIn' => false]);
  exit;
}

echo json_encode([
  'loggedIn' => true,
  'username' => $user['username'],
  'balance' => $user['wallet_balance'],
  'kyc' => $user['kyc_status']
]);
