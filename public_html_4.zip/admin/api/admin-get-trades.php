<?php
ini_set('display_errors', 0); // Hide errors from users
ini_set('log_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');

// Robust error handler to always return JSON
set_exception_handler(function($e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Server error: ' . $e->getMessage()
    ]);
    exit;
});

set_error_handler(function($errno, $errstr, $errfile, $errline) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => "Server error: $errstr at $errfile:$errline"
    ]);
    exit;
});

// Database connection
require_once 'config.php'; // make sure $pdo is defined

$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$limit = 15;
$offset = ($page - 1) * $limit;

$where = [];
$params = [];

// Filters
if (!empty($_GET['status'])) {
    $where[] = "status = :status";
    $params[':status'] = $_GET['status'];
}
if (!empty($_GET['email'])) {
    $where[] = "email LIKE :email";
    $params[':email'] = '%' . $_GET['email'] . '%';
}
if (!empty($_GET['date'])) {
    $where[] = "DATE(created_at) = :date";
    $params[':date'] = $_GET['date'];
}

$where_sql = $where ? "WHERE " . implode(" AND ", $where) : "";

// Total count for pagination
$stmt = $pdo->prepare("SELECT COUNT(*) FROM trades $where_sql");
$stmt->execute($params);
$total = $stmt->fetchColumn();
$totalPages = ceil($total / $limit);

// Main query
$stmt = $pdo->prepare("SELECT id, email, amount, status, created_at FROM trades $where_sql ORDER BY id DESC LIMIT :offset, :limit");
foreach ($params as $k => $v) {
    $stmt->bindValue($k, $v);
}
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->execute();
$trades = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode([
    'success' => true,
    'trades' => $trades,
    'page' => $page,
    'totalPages' => $totalPages,
]);
exit;
?>
