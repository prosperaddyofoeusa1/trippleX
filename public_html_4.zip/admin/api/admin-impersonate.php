<?php
session_start();
require_once 'config.php';
$user_id = (int)($_GET['user_id'] ?? 0);

// Security: Only allow if admin is logged in!
if (!isset($_SESSION['admin_logged_in'])) {
    die("Not authorized");
}
if (!$user_id) die("Invalid user id");

$_SESSION['impersonate_user'] = $user_id;
header("Location: ../user-dashboard.php"); // change to user dashboard path
exit;
?>
