<?php
header('Content-Type: application/json');
ini_set('display_errors', 1);  // REMOVE ON PRODUCTION
error_reporting(E_ALL);

require_once '../../config.php'; // Adjust as needed

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$where = '';
$params = [];

if ($search) {
  $where = "WHERE u.name LIKE ? OR u.email LIKE ?";
  $params[] = "%$search%";
  $params[] = "%$search%";
}

$sql = "SELECT m.id, u.name AS user, u.email, m.status, m.hash_rate, m.balance, m.started_at
        FROM mining m
        JOIN users u ON m.user_id = u.id
        $where
        ORDER BY m.started_at DESC";

try {
    $stmt = $mysqli->prepare($sql);
    if ($params) $stmt->bind_param(str_repeat('s', count($params)), ...$params);
    $stmt->execute();
    $res = $stmt->get_result();

    $miners = [];
    while ($row = $res->fetch_assoc()) {
      $miners[] = [
        "id"      => $row["id"],
        "user"    => $row["user"],
        "email"   => $row["email"],
        "status"  => $row["status"],
        "hash"    => $row["hash_rate"] . " Mh/s",
        "balance" => number_format($row["balance"], 8) . " BTC",
        "started" => date("Y-m-d H:i", strtotime($row["started_at"]))
      ];
    }

    echo json_encode(["miners" => $miners]);
} catch(Exception $e) {
    // If there's a DB error or code bug, still send a valid JSON:
    echo json_encode(["miners" => [], "error" => $e->getMessage()]);
}
?>
