<?php
require_once '../config.php'; // update the path if needed

$search = $_GET['search'] ?? '';
$where = '';
$params = [];
$types = '';

if (!empty($search)) {
    $where = "WHERE username LIKE ? OR action LIKE ? OR details LIKE ? OR ip_address LIKE ?";
    $searchTerm = "%$search%";
    $params = [$searchTerm, $searchTerm, $searchTerm, $searchTerm];
    $types = 'ssss';
}

$sql = "SELECT * FROM logs " . $where . " ORDER BY created_at DESC LIMIT 300";
$stmt = $mysqli->prepare($sql);

if ($where) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

$logs = [];
while ($row = $result->fetch_assoc()) {
    $logs[] = $row;
}
echo json_encode(['logs' => $logs]);
