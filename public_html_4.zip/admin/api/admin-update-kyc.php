<?php
require_once '../../config.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);
$id = intval($data['id'] ?? 0);
$status = in_array($data['status'], ['approved','rejected']) ? $data['status'] : null;

if (!$id || !$status) {
  http_response_code(400);
  echo json_encode(["success"=>false, "message"=>"Invalid data"]);
  exit;
}

$stmt = $mysqli->prepare("UPDATE kyc_requests SET status=?, updated_at=NOW() WHERE id=?");
$stmt->bind_param('si', $status, $id);
$stmt->execute();

echo json_encode(["success"=>true]);
