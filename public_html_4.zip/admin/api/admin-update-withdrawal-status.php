<?php
// File: /admin/api/admin-update-withdrawal-status.php
ini_set('display_errors', 1);
header('Content-Type: application/json');
require_once 'config.php';

try {
    $data = json_decode(file_get_contents('php://input'), true);
    $id = intval($data['id'] ?? 0);
    $status = in_array($data['status'] ?? '', ['approved', 'rejected']) ? $data['status'] : '';

    if (!$id || !$status) throw new Exception("Invalid input");
    $stmt = $pdo->prepare("UPDATE withdrawals SET status = :status WHERE id = :id");
    $stmt->execute([':status' => $status, ':id' => $id]);
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
