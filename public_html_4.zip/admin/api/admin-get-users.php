<?php
session_start();
if (empty($_SESSION['admin_logged_in'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Admin not authenticated']);
    exit;
}
// File: api/admin-get-users.php

header('Content-Type: application/json');
require_once '../config.php'; // Adjust path if needed

$page = max((int)($_GET['page'] ?? 1), 1);
$perPage = max((int)($_GET['per_page'] ?? 15), 1);

$search       = trim($_GET['search'] ?? '');
$status       = $_GET['status'] ?? '';
$kyc_status   = $_GET['kyc_status'] ?? '';
$email_status = $_GET['email_verified'] ?? '';
$date_from    = $_GET['date_from'] ?? '';
$date_to      = $_GET['date_to'] ?? '';

$where = [];
$params = [];

if ($search) {
    $where[] = "(name LIKE ? OR email LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if ($status) {
    $where[] = "status = ?";
    $params[] = $status;
}
if ($kyc_status) {
    $where[] = "kyc_status = ?";
    $params[] = $kyc_status;
}
if ($email_status !== '') {
    $where[] = "email_verified = ?";
    $params[] = $email_status === '1' ? 1 : 0;
}
if ($date_from) {
    $where[] = "DATE(created_at) >= ?";
    $params[] = $date_from;
}
if ($date_to) {
    $where[] = "DATE(created_at) <= ?";
    $params[] = $date_to;
}
$whereSql = $where ? 'WHERE '.implode(' AND ', $where) : '';
$offset = ($page - 1) * $perPage;

try {
    // Use $pdo from config.php
    // 1. Get total count
    $countStmt = $pdo->prepare("SELECT COUNT(*) FROM users $whereSql");
    $countStmt->execute($params);
    $total_count = (int)$countStmt->fetchColumn();

    // 2. Get user rows
    $sql = "SELECT id, name, email, wallet_balance, credit_score, kyc_status, status, ip_address, location, created_at, email_verified
            FROM users $whereSql
            ORDER BY id DESC
            LIMIT $perPage OFFSET $offset";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    $users = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $users[] = [
            'id'            => (int)$row['id'],
            'name'          => $row['name'],
            'email'         => $row['email'],
            'wallet_balance'=> (float)$row['wallet_balance'],
            'credit_score'  => (int)$row['credit_score'],
            'kyc_status'    => $row['kyc_status'],
            'status'        => $row['status'],
            'ip_address'    => $row['ip_address'],
            'location'      => $row['location'],
            'created_at'    => $row['created_at'],
            'email_verified'=> (int)$row['email_verified'],
        ];
    }

    echo json_encode([
        'success' => true,
        'users'   => $users,
        'total_count' => $total_count
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Server error: ' . $e->getMessage()
    ]);
}
