<?php
// File: api/admin-send-notification.php
header('Content-Type: application/json');
require '../config.php';

$data = json_decode(file_get_contents("php://input"), true);
$user_id = (int)($data['user_id'] ?? 0);
$type = $data['type'] ?? '';
$subject = trim($data['subject'] ?? '');
$message = trim($data['message'] ?? '');

if (!$user_id || !$subject || !$message) {
    echo json_encode(['success' => false, 'message' => 'Invalid input']);
    exit;
}

try {
    // Example: fetch user email/phone
    $pdo = new PDO("mysql:host=localhost;dbname=YOUR_DB;charset=utf8mb4", "YOUR_USER", "YOUR_PASS", [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
    $stmt = $pdo->prepare("SELECT email, phone FROM users WHERE id=?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) throw new Exception("User not found");

    // Email example
    if ($type == 'email' || $type == 'all') {
        // Replace this with PHPMailer or similar in real world!
        mail($user['email'], $subject, $message, "From: admin@yourdomain.com");
    }
    // In-app: insert to notifications table
    if ($type == 'in_app' || $type == 'all') {
        $pdo->prepare("INSERT INTO notifications (user_id, subject, message, created_at) VALUES (?, ?, ?, NOW())")
            ->execute([$user_id, $subject, $message]);
    }
    // SMS example (use API in production)
    if ($type == 'sms' || $type == 'all') {
        // send_sms($user['phone'], $message);
    }

    echo json_encode(['success' => true]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
