<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');
require_once 'config.php'; // Make sure this is correct!

$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

$where = [];
$params = [];

if (!empty($_GET['status'])) {
    $where[] = "k.status = :status";
    $params[':status'] = $_GET['status'];
}
if (!empty($_GET['date'])) {
    $where[] = "DATE(k.created_at) = :date";
    $params[':date'] = $_GET['date'];
}

$where_sql = $where ? "WHERE " . implode(" AND ", $where) : "";

// Count total
$stmt = $pdo->prepare("SELECT COUNT(*) FROM kyc_requests k $where_sql");
$stmt->execute($params);
$total = $stmt->fetchColumn();
$totalPages = ceil($total / $limit);

// Main query (include user email if you have users table)
$sql = "SELECT k.id, k.user_id, k.status, k.doc, k.document_type, k.document_number, k.document_url, k.created_at, k.updated_at";
if (columnExists($pdo, 'users', 'email')) $sql .= ", u.email";
$sql .= " FROM kyc_requests k";
if (columnExists($pdo, 'users', 'email')) $sql .= " LEFT JOIN users u ON k.user_id = u.id";
$sql .= " $where_sql ORDER BY k.id DESC LIMIT :offset, :limit";

$stmt = $pdo->prepare($sql);
foreach ($params as $k => $v) $stmt->bindValue($k, $v);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->execute();
$requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode([
    'success' => true,
    'kyc_requests' => $requests,
    'page' => $page,
    'totalPages' => $totalPages
]);

// Helper function to check for column existence
function columnExists($pdo, $table, $column) {
    $result = $pdo->query("SHOW COLUMNS FROM `$table` LIKE '$column'");
    return $result && $result->rowCount() > 0;
}
