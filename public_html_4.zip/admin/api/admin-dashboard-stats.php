<?php
session_start();

// Display errors only for debugging (remove in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Set header before output
header('Content-Type: application/json');

// Authentication check
if (empty($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Admin not authenticated']);
    exit;
}

require_once "config.php"; // PDO connection

try {
    // Total Users
    $stmt = $pdo->query("SELECT COUNT(*) as cnt FROM users");
    $totalUsers = (int) $stmt->fetchColumn();

    // Pending KYC
    $stmt = $pdo->query("SELECT COUNT(*) as cnt FROM users WHERE kyc_status = 'pending'");
    $pendingKYC = (int) $stmt->fetchColumn();

    // Pending Withdrawals
    $stmt = $pdo->query("SELECT COUNT(*) as cnt FROM withdrawals WHERE status = 'pending'");
    $pendingWithdrawals = (int) $stmt->fetchColumn();

    // Ongoing Trades
    $stmt = $pdo->query("SELECT COUNT(*) as cnt FROM trades WHERE status IN ('open', 'processing')");
    $ongoingTrades = (int) $stmt->fetchColumn();

    // Platform Balance
    $stmt = $pdo->query("SELECT SUM(balance) as total FROM platform_wallets");
    $platformBalance = (float) $stmt->fetchColumn();
    $platformBalanceFmt = '$' . number_format($platformBalance, 2);

    echo json_encode([
        "success" => true,
        "stats" => [
            "totalUsers" => $totalUsers,
            "pendingKYC" => $pendingKYC,
            "pendingWithdrawals" => $pendingWithdrawals,
            "ongoingTrades" => $ongoingTrades,
            "platformBalance" => $platformBalanceFmt
        ]
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Server error: " . $e->getMessage()
    ]);
}
