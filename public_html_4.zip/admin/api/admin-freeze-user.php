<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');
require 'config.php';

$data = json_decode(file_get_contents("php://input"), true);
$id = intval($data['id'] ?? 0);

if (!$id) {
    echo json_encode(['success'=>false, 'message'=>'Invalid ID']);
    exit;
}

// Get current status
$stmt = $pdo->prepare("SELECT status FROM users WHERE id = :id");
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$user) {
    echo json_encode(['success'=>false, 'message'=>'User not found']);
    exit;
}
$newStatus = $user['status'] === 'active' ? 'frozen' : 'active';

$stmt = $pdo->prepare("UPDATE users SET status = :status WHERE id = :id");
$stmt->bindValue(':status', $newStatus);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$success = $stmt->execute();

echo json_encode(['success'=>$success, 'new_status'=>$newStatus]);
?>
