<?php
session_start();
require_once __DIR__ . '/../db-connect.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  http_response_code(405);
  echo json_encode(['success' => false, 'message' => 'Invalid request method']);
  exit;
}

$data = json_decode(file_get_contents("php://input"), true);
$userId = intval($data['id'] ?? 0);

if (!$userId || !isset($_SESSION['admin_id'])) {
  echo json_encode(['success' => false, 'message' => 'Invalid admin session or user ID']);
  exit;
}

// Generate temporary token
$token = bin2hex(random_bytes(32));
$expires = date('Y-m-d H:i:s', time() + 1800); // 30 minutes

// Store token
$stmt = $pdo->prepare("INSERT INTO user_tokens (user_id, token, expires_at) VALUES (?, ?, ?)");
$stmt->execute([$userId, $token, $expires]);

echo json_encode([
  'success' => true,
  'redirect' => "/dashboard.html?token=$token"
]);
