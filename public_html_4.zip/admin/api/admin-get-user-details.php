<?php
require 'config.php';
header('Content-Type: application/json');

$id = intval($_GET['id'] ?? 0);
if (!$id) die(json_encode(['success'=>false,'message'=>'Invalid ID']));
$user = $pdo->prepare("SELECT * FROM users WHERE id=?");
$user->execute([$id]);
$details = $user->fetch(PDO::FETCH_ASSOC);
if (!$details) die(json_encode(['success'=>false,'message'=>'User not found']));

// You can add activity summary if you want
$details['total_deposits'] = $pdo->query("SELECT SUM(amount) FROM deposits WHERE user_id=$id")->fetchColumn() ?: 0;
$details['total_withdrawals'] = $pdo->query("SELECT SUM(amount) FROM withdrawals WHERE user_id=$id")->fetchColumn() ?: 0;
$details['total_trades'] = $pdo->query("SELECT COUNT(*) FROM trades WHERE user_id=$id")->fetchColumn() ?: 0;
$details['total_referrals'] = $pdo->query("SELECT COUNT(*) FROM referrals WHERE referrer_id=$id")->fetchColumn() ?: 0;

echo json_encode(['success'=>true,'user_details'=>$details]);
?>
