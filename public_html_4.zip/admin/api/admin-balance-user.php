<?php
require_once '../config.php';
header('Content-Type: application/json');
session_start(); // Needed if tracking admin
$data = json_decode(file_get_contents('php://input'), true);

$id = (int)($data['id'] ?? 0);
$amount = floatval($data['amount'] ?? 0);
$desc = trim($data['desc'] ?? 'Manual admin adjustment');
$adminId = $_SESSION['admin_id'] ?? null;

if (!$id || !$amount) {
    echo json_encode(['success' => false, 'message' => 'Missing fields']);
    exit;
}
try {
    $pdo->beginTransaction();
    $stmt = $pdo->prepare("SELECT wallet_balance FROM users WHERE id=? FOR UPDATE");
    $stmt->execute([$id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$user) throw new Exception('User not found');
    $before = $user['wallet_balance'];
    $after = $before + $amount;
    $type = $amount > 0 ? 'credit' : 'debit';

    $stmt = $pdo->prepare("UPDATE users SET wallet_balance=? WHERE id=?");
    $stmt->execute([$after, $id]);

    // Record history
    $stmt = $pdo->prepare("INSERT INTO balance_history (user_id, admin_id, amount, balance_before, balance_after, description, type) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$id, $adminId, $amount, $before, $after, $desc, $type]);

    $pdo->commit();
    echo json_encode(['success' => true]);
} catch(Exception $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
