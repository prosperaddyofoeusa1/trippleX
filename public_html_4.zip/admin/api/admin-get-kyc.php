<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../../config.php'; // Update if needed

header('Content-Type: application/json');
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$where = "";
$params = [];

if ($search) {
  $where = "AND (u.name LIKE ? OR u.email LIKE ?)";
  $params[] = "%$search%";
  $params[] = "%$search%";
}

$sql = "SELECT k.id, u.name AS user, u.email, k.status, k.doc, k.created_at
        FROM kyc_requests k
        JOIN users u ON k.user_id = u.id
        WHERE 1=1 $where
        ORDER BY k.created_at DESC";

$stmt = $mysqli->prepare($sql);
if ($params) $stmt->bind_param(str_repeat('s', count($params)), ...$params);
$stmt->execute();
$res = $stmt->get_result();

$requests = [];
while ($row = $res->fetch_assoc()) {
  $requests[] = [
    "id" => $row["id"],
    "user" => $row["user"],
    "email" => $row["email"],
    "status" => $row["status"],
    "doc" => $row["doc"],
    "date" => date("Y-m-d H:i", strtotime($row["created_at"]))
  ];
}

echo json_encode(["requests" => $requests]);
