<?php
header('Content-Type: application/json');
require '../config.php';

// Example: Get the count of trades per day for last 7 days
$data = [];
$labels = [];
for($i=6; $i>=0; $i--) {
  $date = date('Y-m-d', strtotime("-$i days"));
  $labels[] = date('M j', strtotime($date));
  $stmt = $pdo->prepare("SELECT COUNT(*) FROM trades WHERE DATE(created_at) = ?");
  $stmt->execute([$date]);
  $data[] = (int)$stmt->fetchColumn();
}

echo json_encode([
  'success' => true,
  'chartData' => [
    'labels' => $labels,
    'data' => $data
  ]
]);
