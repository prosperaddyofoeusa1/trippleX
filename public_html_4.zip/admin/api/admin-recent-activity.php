<?php
header('Content-Type: application/json');
require '../config.php';

$stmt = $pdo->prepare("SELECT type, user, created_at as time FROM activity_logs ORDER BY created_at DESC LIMIT 10");
$stmt->execute();
$activities = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode([
  'success' => true,
  'activities' => $activities
]);
