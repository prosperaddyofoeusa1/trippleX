<?php
header('Content-Type: application/json');
require_once '../../config.php';

$data = json_decode(file_get_contents("php://input"), true);
$id = intval($data['id'] ?? 0);
$status = $data['status'] ?? '';

if (!$id || !in_array($status, ['active','paused'])) {
  http_response_code(400);
  echo json_encode(["success"=>false,"message"=>"Invalid request"]);
  exit;
}

// Optionally, you may adjust the hash_rate here when pausing/starting
$hash_rate = ($status === 'active') ? "150" : "0";

$stmt = $mysqli->prepare("UPDATE mining SET status=?, hash_rate=? WHERE id=?");
$stmt->bind_param("ssi", $status, $hash_rate, $id);
$stmt->execute();

echo json_encode(["success"=>true]);
?>
