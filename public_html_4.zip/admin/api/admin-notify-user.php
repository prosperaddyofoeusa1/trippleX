<?php
require_once '../config.php';
header('Content-Type: application/json');
$data = json_decode(file_get_contents('php://input'), true);

$id = (int)($data['id'] ?? 0);
$message = trim($data['message'] ?? '');

if (!$id || !$message) {
    echo json_encode(['success' => false, 'message' => 'Missing fields']);
    exit;
}

try {
    // Insert notification in DB
    $stmt = $pdo->prepare("INSERT INTO notifications (user_id, message, delivery_method) VALUES (?, ?, 'dashboard')");
    $stmt->execute([$id, $message]);

    // Get user email
    $stmt = $pdo->prepare("SELECT email, name FROM users WHERE id = ?");
    $stmt->execute([$id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    $emailSent = false;
    if ($user && filter_var($user['email'], FILTER_VALIDATE_EMAIL)) {
        // Send email using PHP mail() or PHPMailer (recommended)
        $subject = "New Notification from Tripple Exchange";
        $body = "Dear {$user['name']},\n\n$message\n\n-- Tripple Exchange Admin";
        // If using PHPMailer, configure here!
        // mail($user['email'], $subject, $body); // Use proper mail function or PHPMailer

        // Log delivery status (simulate)
        $pdo->prepare("UPDATE notifications SET delivered = 'yes', delivery_method = 'dashboard,email', delivered_at = NOW() WHERE user_id = ? ORDER BY id DESC LIMIT 1")->execute([$id]);
        $emailSent = true;
    }

    echo json_encode(['success' => true, 'emailSent' => $emailSent]);
} catch(Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
