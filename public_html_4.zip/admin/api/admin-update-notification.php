<?php
header('Content-Type: application/json');
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/config.php';

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request');
    }

    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $recipient = isset($_POST['recipient']) ? trim($_POST['recipient']) : null;
    $title = isset($_POST['title']) ? trim($_POST['title']) : '';
    $message = isset($_POST['message']) ? trim($_POST['message']) : '';

    if (!$id || $title === '' || $message === '') {
        throw new Exception('Invalid input');
    }

    $stmt = $pdo->prepare("UPDATE notifications SET recipient=:recipient, title=:title, message=:message WHERE id=:id");
    $stmt->execute([
        ':recipient' => $recipient ?: null,
        ':title' => $title,
        ':message' => $message,
        ':id' => $id
    ]);

    echo json_encode(['success' => true]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
