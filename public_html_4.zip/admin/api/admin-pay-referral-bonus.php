<?php
header('Content-Type: application/json');
require_once '../../config.php';
$data = json_decode(file_get_contents("php://input"), true);

$id = intval($data['id'] ?? 0);

if (!$id) {
  http_response_code(400);
  echo json_encode(["success"=>false,"message"=>"Invalid referral id"]);
  exit;
}

$stmt = $mysqli->prepare("UPDATE referrals SET bonus_paid=1 WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();

echo json_encode(["success"=>true]);
?>
