<?php
// File: api/admin-adjust-balance.php
header('Content-Type: application/json');
require '../config.php';

$data = json_decode(file_get_contents("php://input"), true);
$user_id = (int)($data['user_id'] ?? 0);
$action = $data['action'] ?? '';
$amount = (float)($data['amount'] ?? 0);
$reason = trim($data['reason'] ?? '');

if (!$user_id || !$action || $amount <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid input']);
    exit;
}
try {
    $pdo = new PDO("mysql:host=localhost;dbname=YOUR_DB;charset=utf8mb4", "YOUR_USER", "YOUR_PASS", [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
    $pdo->beginTransaction();

    $stmt = $pdo->prepare("SELECT wallet_balance FROM users WHERE id=? FOR UPDATE");
    $stmt->execute([$user_id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$row) throw new Exception("User not found");

    $new_balance = (float)$row['wallet_balance'];
    if ($action == "deposit") $new_balance += $amount;
    elseif ($action == "withdraw") $new_balance = max(0, $new_balance - $amount);
    elseif ($action == "set") $new_balance = $amount;
    else throw new Exception("Invalid action");

    $up = $pdo->prepare("UPDATE users SET wallet_balance=? WHERE id=?");
    $up->execute([$new_balance, $user_id]);

    // (Optional) Log balance change
    $log = $pdo->prepare("INSERT INTO balance_logs (user_id, action, amount, reason, admin_id, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
    $admin_id = 1; // Replace with session admin ID
    $log->execute([$user_id, $action, $amount, $reason, $admin_id]);

    $pdo->commit();
    echo json_encode(['success' => true, 'balance' => $new_balance]);
} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
