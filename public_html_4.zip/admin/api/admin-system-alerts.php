<?php
header('Content-Type: application/json');
// You might not need a DB call if you set alerts manually
$notices = [
  ['message'=>'Scheduled server restart at midnight','level'=>'warning','time'=>date('Y-m-d H:i:s')]
];

echo json_encode([
  'success' => true,
  'notices' => $notices
]);
