<?php
session_start();
require '../../config.php';
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    http_response_code(401); exit;
}
$id = intval($_POST['id'] ?? $_GET['id'] ?? 0);
if($id) $mysqli->query("DELETE FROM deposit_addresses WHERE id=$id");
echo json_encode(['success'=>true]);
?>
