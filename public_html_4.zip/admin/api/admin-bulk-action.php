<?php
require '../config.php';
$data = json_decode(file_get_contents('php://input'), true);
$type = $data['type']??'';
$ids = $data['ids']??[];
if(!$ids || !is_array($ids)) die(json_encode(['success'=>false,'message'=>'Invalid users']));
switch($type){
  case 'freeze':
    $in = implode(',', array_fill(0, count($ids), '?'));
    $pdo->prepare("UPDATE users SET status='frozen' WHERE id IN ($in)")->execute($ids);
    break;
  case 'unfreeze':
    $in = implode(',', array_fill(0, count($ids), '?'));
    $pdo->prepare("UPDATE users SET status='active' WHERE id IN ($in)")->execute($ids);
    break;
  case 'send-notification':
    $msg = trim($data['message']??'');
    if(!$msg) die(json_encode(['success'=>false,'message'=>'No message']));
    $stmt = $pdo->prepare("INSERT INTO notifications (user_id, message, created_at) VALUES (?, ?, NOW())");
    foreach($ids as $uid) $stmt->execute([$uid, $msg]);
    break;
  default: die(json_encode(['success'=>false,'message'=>'Unknown action']));
}
echo json_encode(['success'=>true]);
