<?php
header('Content-Type: application/json');
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/config.php';

try {
    // Accept both DELETE and GET for easier frontend testing
    $id = isset($_REQUEST['id']) ? intval($_REQUEST['id']) : 0;

    if (!$id) {
        throw new Exception('Invalid ID');
    }

    $stmt = $pdo->prepare("DELETE FROM notifications WHERE id = :id");
    $stmt->execute([':id' => $id]);

    echo json_encode(['success' => true]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
