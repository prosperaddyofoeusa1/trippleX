<?php
// Place in /admin/api/admin-get-trade-details.php
header('Content-Type: application/json');
require_once 'config.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$id) {
    echo json_encode(['success' => false, 'message' => 'Missing trade ID']);
    exit;
}

$stmt = $pdo->prepare("SELECT id, email, amount, status, created_at, details FROM trades WHERE id = :id LIMIT 1");
$stmt->execute([':id' => $id]);
$trade = $stmt->fetch(PDO::FETCH_ASSOC);

if ($trade) {
    echo json_encode(['success' => true, 'trade' => $trade]);
} else {
    echo json_encode(['success' => false, 'message' => 'Trade not found']);
}
?>
