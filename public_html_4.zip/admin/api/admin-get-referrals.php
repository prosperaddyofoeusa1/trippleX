<?php
header('Content-Type: application/json');
require_once '../../config.php';

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$where = '';
$params = [];

if ($search) {
  $where = "WHERE referrer.email LIKE ? OR referrer.name LIKE ? OR referred.email LIKE ?";
  $params = ["%$search%", "%$search%", "%$search%"];
}

$sql = "
SELECT 
  r.id,
  referrer.id AS referrer_id,
  referrer.name AS referrer_name,
  referrer.email AS referrer_email,
  (
    SELECT COUNT(*) FROM trades t WHERE t.user_id = r.referrer_id AND t.status = 'completed'
  ) AS completed_trades,
  referred.id AS referred_id,
  referred.name AS referred_name,
  referred.email AS referred_email,
  r.date,
  r.bonus_paid
FROM referrals r
JOIN users referrer ON r.referrer_id = referrer.id
JOIN users referred ON r.referred_id = referred.id
$where
ORDER BY r.date DESC
";

$stmt = $mysqli->prepare($sql);
if ($params) $stmt->bind_param(str_repeat('s', count($params)), ...$params);
$stmt->execute();
$res = $stmt->get_result();

$referrals = [];
while ($row = $res->fetch_assoc()) {
  $referrals[] = [
    "id" => $row["id"],
    "referrer_id" => $row["referrer_id"],
    "referrer_name" => $row["referrer_name"],
    "referrer_email" => $row["referrer_email"],
    "completed_trades" => intval($row["completed_trades"]),
    "referred_id" => $row["referred_id"],
    "referred_name" => $row["referred_name"],
    "referred_email" => $row["referred_email"],
    "date" => $row["date"],
    "bonus_paid" => intval($row["bonus_paid"]) ? 1 : 0
  ];
}
echo json_encode(["referrals" => $referrals]);
?>
