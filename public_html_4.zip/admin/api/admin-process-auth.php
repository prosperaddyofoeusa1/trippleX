<?php
// File: api/admin-process-auth.php
header('Content-Type: application/json');
require '../config.php';

$data = json_decode(file_get_contents("php://input"), true);
$user_id = (int)($data['user_id'] ?? 0);
$action = $data['action'] ?? '';
$message = trim($data['message'] ?? '');

if (!$user_id || !$action) { echo json_encode(['success'=>false, 'message'=>'Missing input']); exit; }

try {
    $pdo = new PDO("mysql:host=localhost;dbname=YOUR_DB;charset=utf8mb4", "YOUR_USER", "YOUR_PASS", [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
    if ($action == 'verify_email') {
        $pdo->prepare("UPDATE users SET email_verified=1 WHERE id=?")->execute([$user_id]);
    } elseif ($action == 'reset_2fa') {
        $pdo->prepare("UPDATE users SET two_fa_secret=NULL WHERE id=?")->execute([$user_id]);
    } elseif ($action == 'verify_phone') {
        $pdo->prepare("UPDATE users SET phone_verified=1 WHERE id=?")->execute([$user_id]);
    } elseif ($action == 'approve_kyc') {
        $pdo->prepare("UPDATE users SET kyc_status='approved' WHERE id=?")->execute([$user_id]);
    } else {
        throw new Exception("Unknown action");
    }
    // Optionally send notification (see next API)
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
