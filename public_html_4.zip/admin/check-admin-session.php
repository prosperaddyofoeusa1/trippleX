// check-admin-session.php
<?php
session_start();
header('Content-Type: application/json');
echo json_encode(['authenticated' => isset($_SESSION['admin'])]);
